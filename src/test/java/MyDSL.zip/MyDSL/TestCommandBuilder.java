package MyDSL;

import java.util.Collections;
import java.util.List;

public class TestCommandBuilder {
    ComandBuilder comandBuilder;

    public void start(){
        comandBuilder = new ComandBuilder();
        List<MyDimension> myDimensionList = Collections.EMPTY_LIST;
        comandBuilder.addListOfDimensions(myDimensionList).addDimension
    }
}
