package MyDSL;

import com.sun.jna.platform.win32.Guid;

import java.awt.Dimension;

public class MyDimension {

    private static Dimension dimension;

    private static Guid.GUID Id;

    public MyDimension(Dimension dimension){
        dimension=dimension;
        Id = Guid.GUID.newGuid();
    }
}
