package MyDSL;

import com.sun.jna.platform.win32.Guid;


import java.awt.Dimension;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

public class ComandBuilder {

    private static Command command;
    private static Guid.GUID dimId = Guid.GUID.newGuid();

    private static Map<Guid.GUID, List<MyDimension>> listOfDimensions;

    public ComandBuilder(){
            command = new Command();
    }

    public static Command addDimension(){

        Dimension dimension = new Dimension();
        MyDimension myDimension = new MyDimension(dimension);

        Map<Guid.GUID, List<MyDimension>> myMap = command.getCommands();
        myMap.computeIfPresent(dimId,(k,v) -> {
            v.add(myDimension);
            return v;}
            );
        command.setCommands(myMap);
        return command;
    }

    public static Command addListOfDimensions(List<MyDimension> aList){

        listOfDimensions = new HashMap<>();

        listOfDimensions.put(dimId,aList);
        command.setCommands(listOfDimensions);

        return command;
    }

    private void addDimension(List<Object> aList){


    }

}
