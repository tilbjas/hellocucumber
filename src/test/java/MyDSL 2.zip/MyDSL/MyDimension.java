package MyDSL;

import com.sun.jna.platform.win32.Guid;

import java.awt.Dimension;

public class MyDimension {

    public static Dimension dimension;

    public static Guid.GUID Id;

    public MyDimension(Dimension dimension){
        dimension=dimension;
        Id = Guid.GUID.newGuid();
    }
}
