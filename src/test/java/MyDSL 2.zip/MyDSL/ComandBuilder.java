package MyDSL;

import com.sun.jna.platform.win32.Guid;

import java.awt.*;
import java.util.*;
import java.util.List;

public class ComandBuilder {
    public static class Builder {
        private static Command command;
        private static String dimId = Guid.GUID.newGuid().toGuidString();

        private static Map<String, List<MyDimension>> listOfDimensions;

        public Builder() {
            command = new Command();
        }

        public Builder addDimension() {

            Dimension dimension = new Dimension();
            MyDimension myDimension = new MyDimension(dimension);

            Map<String, List<MyDimension>> myMap = command.getCommands();
            myMap.computeIfPresent(dimId, (k, v) ->
                    {
                        List<MyDimension> newDimList = new ArrayList<>();
                        newDimList.addAll(v);
                        newDimList.add(myDimension);
                        return newDimList;
                    }
            );
            command.setCommands(myMap);
            return this;
        }

        public Builder addListOfDimensions() {
            List<MyDimension> myDimensions = new ArrayList<>();
            listOfDimensions = new HashMap<>();

            listOfDimensions.put(dimId, myDimensions);
            command.setCommands(listOfDimensions);

            return this;
        }


        public Command build() {
            //do create stuff here
            return command;
        }
    }
    private ComandBuilder(){

    }
}
