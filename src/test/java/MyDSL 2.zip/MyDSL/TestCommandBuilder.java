package MyDSL;

import org.junit.Test;

import java.util.Collections;
import java.util.List;

public class TestCommandBuilder {
    Command command;
    @Test
    public void testCommandBuilder(){

        command = new ComandBuilder.Builder()
                 .addListOfDimensions()
                .addDimension().build();

        command.getCommands();
    }
}
